developed by Apurv Nandgaonkar 

#movieAppCineflex

#Screenshot

![Screenshot](https://github.com/D3lfik/movieAppCineflex/blob/master/cineflex.png)
![Screenshot](https://github.com/D3lfik/movieAppCineflex/blob/master/cineflex2.png)
![Screenshot](https://github.com/D3lfik/movieAppCineflex/blob/master/cineflex3.png)
