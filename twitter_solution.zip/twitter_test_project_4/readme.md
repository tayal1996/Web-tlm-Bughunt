link to problem statement : https://docs.google.com/document/d/1qCNl0js9RkZb84q373QMQuBgm6DIsiSd-KqIgS3b7tQ/edit?usp=sharing
